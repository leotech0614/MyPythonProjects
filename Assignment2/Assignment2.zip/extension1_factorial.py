"""
File: extension1_factioral.py
Name: 
-------------------
This program will continually ask our user to give a number
and will calculate the factorial result of the number and print it on the console.

The program ends when the user enter the EXIT number.
"""


def main():
	"""
	TODO:
	"""
	pass


# DO NOT EDIT CODE BELOW THIS LINE #

if __name__ == '__main__':
	main()